import 'package:get/get.dart';
import 'package:tsdoha/services/payment.dart';
import '../../model/payment_details_model.dart';
import '../../model/payment_model.dart';
import '../../utils/shared_preferences.dart';

class PaymentsController extends GetxController {
  final paymentsTotalparents = <Payment>[].obs;
  final paymentsTotalstudents = <Payment>[].obs;
  final totalpaiddetailsparents = <PaymentDetails>[].obs;
  final totalinpaiddetailsparents = <PaymentDetails>[].obs;
  final totalpaiddetailsstudents = <PaymentDetails>[].obs;
  final totalinpaiddetailsstudents = <PaymentDetails>[].obs;
  RxBool isLoading = false.obs;
  late int parentId;

  @override
  void onInit() {
    super.onInit();
    _fetchPaymentsData();
  }

  Future<void> _fetchPaymentsData() async {
    final uid = await SharedData.getFromStorage('parent', 'object', 'uid');
    parentId = uid;
    await _fetchTotalPaymentsParents();
    await _fetchTotalPaidDetailsParents();
    await _fetchTotalInPaidDetailsParents();
  }

  Future<void> _fetchTotalPaymentsParents() async {
    try {
      isLoading.value = true;
      final paymentList = await ApiServicePayment.getPaymentsParentTotal(parentId);
      paymentsTotalparents.assignAll(paymentList);
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> _fetchTotalPaidDetailsParents() async {
    try {
      isLoading.value = true;
      final paidList = await ApiServicePayment.getPaidDetailsParents(parentId);
      totalpaiddetailsparents.assignAll(paidList);
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> _fetchTotalInPaidDetailsParents() async {
    try {
      isLoading.value = true;
      final paidList = await ApiServicePayment.getInPaidDetailsParents(parentId);
      totalinpaiddetailsparents.assignAll(paidList);
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> fetchingTotalPaymentsStudents(int studentId) async {
    try {
      isLoading.value = true;
      final paymentList = await ApiServicePayment.getPaymentsStudentTotal(studentId);
      paymentsTotalstudents.assignAll(paymentList);
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> fetchingTotalPaymentsStudentsDetail(int studentId) async {
    try {
      isLoading.value = true;
      final paymentList = await ApiServicePayment.getPaidDetailsStudents(studentId);
      totalpaiddetailsstudents.assignAll(paymentList);
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> fetchingTotalInPaidDetailsStudent(int studentId) async {
    try {
      isLoading.value = true;
      final paidList = await ApiServicePayment.getInPaidDetailsStudents(studentId);
      totalinpaiddetailsstudents.assignAll(paidList);
    } finally {
      isLoading.value = false;
    }
  }
}
